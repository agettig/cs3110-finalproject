let hours_worked = 110
